﻿using System;
using System.Threading;
using System.Threading.Tasks;
#nullable enable
namespace WhenToDisposeCancellationTokenSources.Examples
{

    public class Service : IDisposable
    {
        private readonly CancellationTokenSource _disposeCts = new CancellationTokenSource();

        public async Task LongRunningOperationAsync(CancellationToken token)
        {
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(_disposeCts.Token, token);

            await PerformOperation(cts.Token);

            static async Task PerformOperation(CancellationToken token)
            {
                // A potentially long running operation that checks
                // the token to stop the execution once requested.
                await Task.Delay(TimeSpan.FromTicks(1), token);
            }
        }

        public void Dispose()
        {
            _disposeCts.Cancel();
        }
    }
}