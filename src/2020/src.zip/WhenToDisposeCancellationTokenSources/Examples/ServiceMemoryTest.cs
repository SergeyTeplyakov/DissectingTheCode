﻿#nullable enable
using System;
using System.Linq;
using FluentAssertions;
using JetBrains.dotMemoryUnit;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace WhenToDisposeCancellationTokenSources.Examples
{
    public class ServiceMemoryTest
    {
        private readonly ITestOutputHelper _output;

        public ServiceMemoryTest(ITestOutputHelper output)
        {
            _output = output;
            DotMemoryUnitTestOutput.SetOutputMethod(data => output.WriteLine(data));
        }

        [Fact]
        public async Task TestMemoryLeak()
        {
            var memoryCheckpoint = dotMemory.Check();
            const int IterationsCount = 1_000;
            using var service = new Service();
            var token = CancellationToken.None;
            //new CancellationTokenSource().Token;
            for (int i = 0; i < IterationsCount; i++)
            {
                await service.LongRunningOperationAsync(token);
            }
            var ctss = Enumerable.Range(1, 100).Select(n => new CancellationTokenSource()).ToList();

            dotMemory.Check(memory =>
            {
                var count2 = memory.GetObjects(t => t.Type.Is<CancellationTokenSource>()).ObjectsCount;
                _output.WriteLine($"Objects: {count2}");
                var count = memory.GetDifference(memoryCheckpoint)
                    .GetSurvivedObjects()
                    .GetObjects(o => o.Type.Is<CancellationTokenSource>())
                    .ObjectsCount;
                _output.WriteLine($"Objects: {count}");
                
                count
                .Should().Be(IterationsCount, "All the cancellation token sources still in memory!");
                GC.KeepAlive(ctss);
                GC.KeepAlive(service);
            });
        }

        [Fact]
        public async Task DebugMemoryLeak()
        {
            const int IterationsCount = 1_000;
            using var service = new Service();
            var token = CancellationToken.None;//new CancellationTokenSource().Token;
            for (int i = 0; i < IterationsCount; i++)
            {
                await service.LongRunningOperationAsync(token);
            }
        }
    }
}